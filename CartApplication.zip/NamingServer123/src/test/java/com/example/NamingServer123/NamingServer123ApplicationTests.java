package com.example.NamingServer123;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NamingServer123ApplicationTests {

	@Test
	void contextLoads() {
	}

}

package com.example.PhoneBookProject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PhoneBookProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}

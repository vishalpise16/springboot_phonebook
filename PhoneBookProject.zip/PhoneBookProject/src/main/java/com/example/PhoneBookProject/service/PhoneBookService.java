package com.example.PhoneBookProject.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.PhoneBookProject.model.PhoneBook;
import com.example.PhoneBookProject.repository.PhoneBookRepository;

@Service
public class PhoneBookService {

	@Autowired
	private PhoneBookRepository phoneBookRepository;
	
	public PhoneBook save(PhoneBook phonebook) {
		return phoneBookRepository.save(phonebook);
	}
	
	public List<PhoneBook> listAll(){
		return phoneBookRepository.findAll();
	}
	
	public String deleteContact(int id) {
		phoneBookRepository.deleteById(id);
		return "Contact Deleted --" +id;
	}
	
	public PhoneBook getContactByID(int id) {
		return phoneBookRepository.findById(id).orElse(null);
	}

	public PhoneBook getContactByName(String name) {
		return phoneBookRepository.findByName(name);
	}
	
	public List<PhoneBook> saveContacts(List<PhoneBook> phoneBook) {
		// TODO Auto-generated method stub
		return phoneBookRepository.saveAll(phoneBook);
	}
	
	public PhoneBook updateContact(PhoneBook phoneBook) {
		PhoneBook p1 = phoneBookRepository.findById(phoneBook.getId()).orElse(null);
		if(p1!=null) {
			p1.setName(phoneBook.getName());
			p1.setEmail(phoneBook.getEmail());
			p1.setNumber(phoneBook.getNumber());
			return phoneBookRepository.save(p1);
		}
		else {
			return phoneBookRepository.save(phoneBook);
		}
	}
	
}

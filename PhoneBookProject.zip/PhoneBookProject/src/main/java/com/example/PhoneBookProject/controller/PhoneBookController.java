package com.example.PhoneBookProject.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.PhoneBookProject.model.PhoneBook;
import com.example.PhoneBookProject.service.PhoneBookService;


import io.swagger.annotations.ApiOperation;

@RestController
@RequestMapping("/phonebook")
public class PhoneBookController {
	
	@Autowired
	private PhoneBookService phoneBookService;
	
	@GetMapping("/status")
	@ApiOperation(value = "Display App Status")
	public String appStatus() {
		return "Application Running";
	}
	
	@GetMapping("/showAll")
	@ApiOperation(value = "Fetch Contacts")
	public List<PhoneBook> showAll() {
		return phoneBookService.listAll();
	}
	
	@GetMapping("/showbyid/{id}")
	@ApiOperation(value = "Fetch Contacts by id")
	public PhoneBook showById(@PathVariable int id) {
		return phoneBookService.getContactByID(id);		
	}
	
	@GetMapping("/showbyname/{name}")
	@ApiOperation(value = "Fetch Contacts by name")
	public PhoneBook showById(@PathVariable String name) {
		return phoneBookService.getContactByName(name);		
	}
	
	@PostMapping("/addContact")
	@ApiOperation(value = "Store Contact")
	public PhoneBook addContact(@RequestBody PhoneBook phoneBook) {
		return phoneBookService.save(phoneBook);
	}
	
	@PostMapping("/addContacts")
	public List<PhoneBook> addProducts(@RequestBody List<PhoneBook> phoneBook) {
		return phoneBookService.saveContacts(phoneBook);
	}
	
	@DeleteMapping("/deleteByID/{id}")
	@ApiOperation(value = "Delete Contact")
	public String deleteContact(@PathVariable int id) {
		phoneBookService.deleteContact(id);
		return "Contact Deleted";
	}
	
	@PutMapping("/updateContact")
	@ApiOperation(value = "Update Contact")
	public PhoneBook updateContact(@RequestBody PhoneBook phoneBook) {
		return phoneBookService.updateContact(phoneBook);
	}
	
	
	
	
}

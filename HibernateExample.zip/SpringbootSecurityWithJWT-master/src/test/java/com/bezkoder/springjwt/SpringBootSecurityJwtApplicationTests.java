package com.bezkoder.springjwt;

import javax.swing.Spring;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.demo.springjwt.repository.UserRepository;
import com.demo.springjwt.security.services.UserDetailsServiceImpl;


@SpringBootTest
public class SpringBootSecurityJwtApplicationTests {

	@Autowired
	private UserDetailsServiceImpl userDetailsServiceImpl;
	
	@Autowired
	private UserRepository userRepository;
	

	
	

}

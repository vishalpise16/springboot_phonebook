# aws-elasticbeanstalk-example
Deploy web application into AWS using Elastic Beanstalk
